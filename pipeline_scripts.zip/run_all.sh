aws s3 ls s3://neurosync-research-in/adni_227_v1.0.0/raw_nifti/ | awk '{print $4}' | grep 'nii.gz$' | xargs -P 2 -n 1 bash ~/n4_one.sh
