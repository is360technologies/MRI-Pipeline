f=$1
B=s3://neurosync-research-in/adni_227_v1.0.0
b=${f%_n4.nii.gz}
aws s3 ls $B/derived/synthseg/${b}_qc.csv >/dev/null 2>&1 && echo SKIP $f && exit 0
w=$(mktemp -d -p ~/work)
mkdir $w/in $w/out
aws s3 cp $B/derived/n4/$f $w/in/ --only-show-errors && docker run --rm -v $w:/data freesurfer/freesurfer:7.4.1 mri_synthseg --i /data/in --o /data/out --parc --vol /data/out/vol.csv --qc /data/out/qc.csv --threads 4 --cpu >/dev/null 2>&1 && aws s3 cp $w/out/${f%.nii.gz}_synthseg.nii.gz $B/derived/synthseg/${b}_synthseg.nii.gz --only-show-errors && aws s3 cp $w/out/vol.csv $B/derived/synthseg/${b}_vol.csv --only-show-errors && aws s3 cp $w/out/qc.csv $B/derived/synthseg/${b}_qc.csv --only-show-errors && echo OK $f || echo FAIL $f
sudo rm -rf $w
