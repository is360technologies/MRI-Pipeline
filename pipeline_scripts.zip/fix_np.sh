B=s3://neurosync-research-in/adni_227_v1.0.0
for s in 099_S_4124_I247513 100_S_4556_I300845 133_S_0629_I19234; do
  w=$HOME/work/np_$s; sudo rm -rf $w; mkdir -p $w/in $w/out
  aws s3 cp $B/derived/n4/${s}_T1w_n4.nii.gz $w/in/ --only-show-errors
  docker run --rm -v $w:/data freesurfer/freesurfer:7.4.1 mri_synthseg --i /data/in --o /data/out --vol /data/out/vol.csv --qc /data/out/qc.csv --threads 1 --cpu > $HOME/np_$s.log 2>&1
  if [ -f $w/out/${s}_T1w_n4_synthseg.nii.gz ]; then
    aws s3 cp $w/out/${s}_T1w_n4_synthseg.nii.gz $B/derived/synthseg/${s}_T1w_synthseg.nii.gz --only-show-errors
    aws s3 cp $w/out/vol.csv $B/derived/synthseg/${s}_T1w_vol.csv --only-show-errors
    aws s3 cp $w/out/qc.csv $B/derived/synthseg/${s}_T1w_qc.csv --only-show-errors
    echo FIXED $s
  else echo STILL_FAIL $s; fi
  sudo rm -rf $w
done
