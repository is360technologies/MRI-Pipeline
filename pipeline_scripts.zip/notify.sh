while kill -0 4199 2>/dev/null; do sleep 60; done
n=$(aws s3 ls s3://neurosync-research-in/adni_227_v1.0.0/derived/synthseg/ | grep -c _qc.csv)
f=$(grep -c FAIL ~/sg.log)
aws sns publish --region ap-south-1 --topic-arn arn:aws:sns:ap-south-1:329992224492:sg-done --subject "SynthSeg finished" --message "SynthSeg run ended. QC files in S3: $n of 227. FAIL lines in log: $f. The instance is still running, so stop it to avoid billing."
