import sys, SimpleITK as sitk
i = sitk.ReadImage(sys.argv[1])
r = sitk.ResampleImageFilter()
r.SetOutputSpacing([1,1,1]); r.SetSize([256,256,256])
r.SetOutputOrigin(i.GetOrigin()); r.SetOutputDirection(i.GetDirection())
r.SetInterpolator(sitk.sitkBSpline)
sitk.WriteImage(r.Execute(i), sys.argv[2])
