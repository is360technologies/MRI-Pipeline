f=$1
B=s3://neurosync-research-in/adni_227_v1.0.0
b=${f%_n4.nii.gz}
aws s3 ls $B/derived/synthstrip/${b}_brainmask.nii.gz >/dev/null 2>&1 && echo SKIP $f && exit 0
w=$(mktemp -d -p ~/work)
aws s3 cp $B/derived/n4/$f $w/in.nii.gz --only-show-errors && python3 ~/synthstrip-docker -i $w/in.nii.gz -o $w/out.nii.gz -m $w/mask.nii.gz >/dev/null 2>&1 && aws s3 cp $w/out.nii.gz $B/derived/synthstrip/${b}_brain.nii.gz --only-show-errors && aws s3 cp $w/mask.nii.gz $B/derived/synthstrip/${b}_brainmask.nii.gz --only-show-errors && echo OK $f || echo FAIL $f
rm -rf $w
