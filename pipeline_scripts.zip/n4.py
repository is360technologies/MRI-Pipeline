import sys
import SimpleITK as sitk
img = sitk.ReadImage(sys.argv[1], sitk.sitkFloat32)
mask = sitk.Cast(sitk.OtsuThreshold(img, 0, 1, 200), sitk.sitkUInt8)
f = [4, 4, 4]
n4 = sitk.N4BiasFieldCorrectionImageFilter()
n4.SetMaximumNumberOfIterations([50, 50, 50, 50])
n4.Execute(sitk.Shrink(img, f), sitk.Shrink(mask, f))
corrected = img / sitk.Exp(n4.GetLogBiasFieldAsImage(img))
sitk.WriteImage(corrected, sys.argv[2])
