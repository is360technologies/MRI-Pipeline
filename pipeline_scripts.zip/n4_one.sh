f=$1
B=s3://neurosync-research-in/adni_227_v1.0.0
o=derived/n4/${f%.nii.gz}_n4.nii.gz
aws s3 ls $B/$o >/dev/null 2>&1 && echo SKIP $f && exit 0
w=$(mktemp -d)
aws s3 cp $B/raw_nifti/$f $w/in.nii.gz --only-show-errors && python3 ~/n4.py $w/in.nii.gz $w/out.nii.gz && aws s3 cp $w/out.nii.gz $B/$o --only-show-errors && echo OK $f || echo FAIL $f
rm -rf $w
