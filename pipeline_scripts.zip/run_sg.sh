aws s3 ls s3://neurosync-research-in/adni_227_v1.0.0/derived/n4/ | awk '{print $4}' | grep '_n4.nii.gz$' | xargs -P 2 -n 1 bash ~/sg_one.sh
